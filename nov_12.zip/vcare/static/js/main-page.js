/* button clicks */

(function (global) {

    // for hiding the login popup
	$("#login-register-page").on('blur',function(){
		$(this).fadeOut(300);
		document.getElementById('abc').style.display = "none";
		$("body").css("overflow", "scroll");
	});

	// for showing the login popup
	$(".loadDefault").click(function(e){
		e.preventDefault();
		$("#login-register-page").fadeIn(300,function(){$(this).focus();});
		$("body").css("overflow", "hidden");
		document.getElementById('abc').style.display = "block";

	});

	$("#login-button").click(function(){
		$("#signup-page").addClass("hide");
		$("#login-page").removeClass("hide");
	});

	$("#signup-button").click(function(){
		$("#login-page").addClass("hide");
		$("#signup-page").removeClass("hide");
	});

	$(".weightGain").click(function () {
	});

	$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
		if (!$(this).next().hasClass('show')) {
			$(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
		}
		var $subMenu = $(this).next(".dropdown-menu");
		$subMenu.toggleClass('show');
		$(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
			$('.dropdown-submenu .show').removeClass("show");
		});
		return false;
	});

})(window);
