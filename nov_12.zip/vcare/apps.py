from django.apps import AppConfig


class VcareConfig(AppConfig):
    name = 'vcare'
