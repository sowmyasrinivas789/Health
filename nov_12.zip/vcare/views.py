from django.shortcuts import render
from django.http import HttpResponse
import os


def index(request):
    return render(request, 'index.html', {'result': "template created"})

def beautyhair(request):
    return render(request, 'beauty/beautyhair.html', {'result': "template created"})

def beautyhands(request):
    return render(request, 'beauty/beautyhands.html', {'result': "template created"})

def beautylegs(request):
    return render(request, 'beauty/beautylegs.html', {'result': "template created"})

def beautyskin(request):
    return render(request, 'beauty/beautyskin.html', {'result': "template created"})

def beautyoralhealth(request):
    return render(request, 'beauty/beautyoralhealth.html', {'result': "template created"})
    
def nutritionnuts(request):
    return render(request, 'nutrition/nutrition food - nuts and seeds.html', {'result': "template created"})

def nutritionfruits(request):
    return render(request, 'nutrition/nutrition food - fruits.html', {'result': "template created"})

def nutritionvegetables(request):
    return render(request, 'nutrition/nutrition food - vegetable.html', {'result': "template created"})

def nutritionreceipes(request):
    return render(request, 'nutrition/nutrition food - receipes.html', {'result': "template created"})
    
def weightgain(request):
    return render(request, 'weightgain/weightgain.html', {'result': "template created"})

def weightloss(request):
    return render(request, 'weightgain/weightloss.html', {'result': "template created"})
    
def weightlosschallenge(request):
    return render(request, 'weightgain/weightloss -30daychallenge.html', {'result': "template created"})
# def first_page(request):
    # path = "img"
    # img_list = os.listdir(path)
    # return render(request, 'first_page.html', {'images': img_list})