/* Setting up Header */
/* var header_dict = {"Home":[] , "AboutUs":[], "Beauty":["Hair", "Skin", "Hands", "Legs"], "WeightLoss":["30 Days Weight Loss challenge"], "Food":["Nutrition", "Receipe", "Veggies", "Fruits", "Nuts"], "WeightGain":[], "Fitness": ["90 Day Challenge", "30 Day Core Challenge Advanced", "30 Day total body challenge"],"":""}

headerdiv = $("ul.header-tab");
$.each(header_dict, function(key, value){
headerdiv.append("<li class='nav-item main-tab fl'><div id="+ key +"><a class='nav-link'>" + key + "</a></div></li>");
subheader = $("#" + key + "");
sub_li_items = "";
$.each(value, function(index, value){
sub_li_items += "<li class='sub-tab' id=" + value + ">" + value + "</li>";
});
subheader.append(sub_li_items);
});
headerdiv.append(subheader); */

/* button clicks */

(function (global) {

	$("#login").addClass("hide");
	$(".loadDefault").click(function(){
	   $("#login").removeClass("hide");
	});

    $("#login-button").click(function(){
        $("#signup-page").addClass("hide");
        $("#login-page").removeClass("hide");

    });
    $("#signup-button").click(function(){
        $("#login-page").addClass("hide");
        $("#signup-page").removeClass("hide");
    });
            $(".weightGain").click(function () {
				alert("onclick");
                //$("<div>").removeClass("indexcontainer").addClass("weightgainphase");
                alert("ndush");
/*                 $.get("weightgain.html", function (data) {
					qqq = data;
                    alert("data"+qqq);
                    $(".indexcontainer").append(data);
                }); */
            });

    $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
        alert("ggggg");
        if (!$(this).next().hasClass('show')) {
            $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
        }
        var $subMenu = $(this).next(".dropdown-menu");
        $subMenu.toggleClass('show');


        $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
            $('.dropdown-submenu .show').removeClass("show");
        });


        return false;
    });


})(window);
