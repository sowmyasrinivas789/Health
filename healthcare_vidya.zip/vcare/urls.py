from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('beauty/', views.index, name='beauty'),
    path('beauty/hair/', views.beautyhair, name='beautyhair'),
    path('beauty/hands/', views.beautyhands, name='beautyhands'),
    path('beauty/legs/', views.beautylegs, name='beautylegs'),
    path('beauty/skin/', views.beautyskin, name='beautyskin'),
    path('beauty/oralhealth/', views.beautyoralhealth, name='beautyoralhealth'),
    path('nutrition/fruits/', views.nutritionfruits, name='nutritionfruits'),
    path('nutrition/vegetables/', views.nutritionvegetables, name='nutritionvegetables'),
    path('nutrition/nutsandseeds/', views.nutritionnuts, name='nutritionnuts'),
    path('nutrition/receipes/', views.nutritionreceipes, name='nutritionreceipes'),
    path('weightgain/weightgain/', views.weightgain, name='weightgain'),
    path('weightloss/weightloss/', views.weightgain, name='weightloss'),
    path('weightloss/weightlosschallenge/', views.weightgain, name='weightlosschallenge'),
]