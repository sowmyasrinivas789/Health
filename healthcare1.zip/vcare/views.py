from django.shortcuts import render
from django.http import HttpResponse
import os


def index(request):
    return render(request, 'index.html', {'result': "template created"})

def beautyhair(request):
    return render(request, 'beautyhair.html', {'result': "template created"})

def beautyhands(request):
    return render(request, 'beautyhands.html', {'result': "template created"})

def beautylegs(request):
    return render(request, 'beautylegs.html', {'result': "template created"})

# def first_page(request):
    # path = "E:\D-Project\ByMe\craftshop\static\img"
    # img_list = os.listdir(path)
    # return render(request, 'first_page.html', {'images': img_list})