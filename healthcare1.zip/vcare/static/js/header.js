(function(global) {
    alert("qqqq");
    $("#navbar-frame").load("navbar.html");
    alert("bswbdbw");
        
})(window);